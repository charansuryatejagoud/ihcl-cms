export function LiveBadge(props) {
  return {
    label: "Live for Public",
    title: "This page is LIVE and publicly available",
    color: "success",
  };
}
