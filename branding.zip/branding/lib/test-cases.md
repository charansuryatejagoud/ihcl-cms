---
title: Test cases for unique identifiers
---


- Should generate on item creation ==> Automated Test Case
- Should ensure identifiers are unique inside a document ==> Automated Test Case
- Should handle rage Duplicate, Delete or, Publish ==> Need to be Manual
- Ensure Cache is reset on start and end of unique identifier check ==> Automated Test Case