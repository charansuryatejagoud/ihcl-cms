export const supportedDocumentFormats = ["docx", "pdf"];
