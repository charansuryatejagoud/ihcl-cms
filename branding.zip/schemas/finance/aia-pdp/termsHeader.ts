export default {
  name: "aiaPdp.tncHeader",
  title: "[AIA PDP] TnC Header",
  type: "object",
  fields: [
    {
      name: "title",
      title: "title",
      type: "string",
    },
  ],
};
