export default {
  name: "hstu.footer.policy-detail",
  title: "[HSTU PDF] Policy Detail Footer",
  type: "header-footer",
};
