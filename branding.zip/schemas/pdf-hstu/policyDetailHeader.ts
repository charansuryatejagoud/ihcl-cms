export default {
  name: "hstu.header.policy-detail",
  title: "[HSTU PDF] Policy Detail Header",
  type: "header-footer",
};
