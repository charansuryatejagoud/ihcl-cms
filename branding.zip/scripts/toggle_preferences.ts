export default [
  { title: "Dark Mode", value: "darkMode" },
  { title: "Screen Lock", value: "screenLock" },
  { title: "Promotional SMS", value: "promotionalSMS" },
  { title: "Promotional Email", value: "promotionalEmail" },
  { title: "Push Notification", value: "pushNotification" },
  { title: "SSL Pinning", value: "sslPinning" },
];
